function f4=f4(x)


Bound=[-100 100];

if nargin==0
    f4 = Bound;
else
    f4=max(abs(x));
end





